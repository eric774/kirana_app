package com.nishant.kirana_kinara;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
